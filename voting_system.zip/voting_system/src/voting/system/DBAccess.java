package voting.system;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

public class DBAccess {
	private Connection con;
	public DBAccess(Connection con) {
		super();
		this.con = con;
	}
	// get value from adhar 
	 	public GetValue getAdharValue(Long adhar) {
	 		GetValue user=null;
	 		try {
	 			String query="select * from  voting_sys where adhar= ?";
	 			PreparedStatement ps=con.prepareStatement(query);
	 			ps.setLong(1, adhar );
	 			ResultSet rs=ps.executeQuery();
	 			while(rs.next()) {
	 				user=new GetValue();
	 				user.setVoting_id(rs.getInt("voting_id"));
	 				user.setName(rs.getString("name"));
	 				user.setAdhar(rs.getLong("adhar"));
	 				user.setState(rs.getString("state"));
	 				user.setDist(rs.getString("dist"));
	 				user.setCity(rs.getString("city"));
	 			}
	 		} catch (SQLException e) {
	 			e.printStackTrace();
	 		}
	 		return user;
	 	}
	 	
// get All ZILA Panchayat 
	 	public ArrayList<ZilaPanchayat> getAllZilaPanchayat(){
	 		ArrayList<ZilaPanchayat> list=new ArrayList<ZilaPanchayat>();
	 		String query="select * from zila_panchayat";
	 		try {
				PreparedStatement ps=con.prepareStatement(query);
				ResultSet rs=ps.executeQuery();
				while(rs.next()) {
					int  zila_id=rs.getInt("zila_id");
					String  symbol_name=rs.getString("symbol_name");
					String  symbol_pick=rs.getString("symbol_pick");
					String  name=rs.getString("name");
					Timestamp  date_time=rs.getTimestamp("date_time");
					ZilaPanchayat zila=new ZilaPanchayat(zila_id,symbol_name,symbol_pick,name,date_time);
					list.add(zila);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return list;
	 		
	 	}
	 // get All block Panchayat 
	 	 	public ArrayList<BlockPanchayat> getAllBlockPanchayat(){
	 	 		ArrayList<BlockPanchayat> list1=new ArrayList<BlockPanchayat>();
	 	 		String query="select * from block_panchayat";
	 	 		try {
	 				PreparedStatement ps=con.prepareStatement(query);
	 				ResultSet rs=ps.executeQuery();
	 				while(rs.next()) {
	 					int  block_id=rs.getInt("block_id");
						String  symbol_name=rs.getString("symbol_name");
						String  symbol_pick=rs.getString("symbol_pick");
						String  name=rs.getString("name");
						Timestamp  date_time=rs.getTimestamp("date_time");
	 					BlockPanchayat block=new BlockPanchayat(block_id,symbol_name,symbol_pick,name,date_time);
	 					list1.add(block);
	 				}
	 			} catch (SQLException e) {
	 				e.printStackTrace();
	 			}
	 			return list1;
	 	 		
	 	 	}
	 	// get All gram Panchayat 
	 	 	public ArrayList<GramPanchayat> getAllGramPanchayat(){
	 	 		ArrayList<GramPanchayat> list2=new ArrayList<GramPanchayat>();
	 	 		String query="select * from gram_panchayat";
	 	 		try {
	 				PreparedStatement ps=con.prepareStatement(query);
	 				ResultSet rs=ps.executeQuery();
	 				while(rs.next()) {
	 					int  gram_id=rs.getInt("gram_id");
						String  symbol_name=rs.getString("symbol_name");
						String  symbol_pick=rs.getString("symbol_pick");
						String  name=rs.getString("name");
						Timestamp  date_time=rs.getTimestamp("date_time");
	 					GramPanchayat gram=new GramPanchayat(gram_id,symbol_name,symbol_pick,name,date_time);
	 					list2.add(gram);
	 				}
	 			} catch (SQLException e) {
	 				e.printStackTrace();
	 			}
	 			return list2;
	 	 		
	 	 	}
	 	// insert value from adhar 
		 	public boolean saveAllValue(VoteData vt) {
		 		boolean f=false;
		 		try {
		 			String query="insert into vote_submit(name,adhar,state,dist,city,zila_panchayat,block_panchayat,gram_panchayat) values(?,?,?,?,?,?,?,?)";
		 			PreparedStatement ps=con.prepareStatement(query);
		 			ps.setString(1, vt.getName() );
		 			ps.setLong(2, vt.getAdhar() );
		 			ps.setString(3, vt.getState() );
		 			ps.setString(4, vt.getDist() );
		 			ps.setString(5, vt.getCity() );
		 			ps.setString(6, vt.getZila_panchayat() );
		 			ps.setString(7, vt.getBlock_panchayat() );
		 			ps.setString(8, vt.getGram_panchayat() );
		 			ps.executeUpdate();
		 			 f=true;
		 		} catch (SQLException e) {
		 			e.printStackTrace();
		 		}
				return f;
		 	}
		 	
		 // get total vote 
		 	public ZilaPanchayatCount getZilaPanchayat() {
		 		ZilaPanchayatCount user=null;
		 		try {
		 			String query="select count(zila_panchayat) from  vote_submit";
		 			PreparedStatement ps=con.prepareStatement(query);
		 			ResultSet rs=ps.executeQuery();
		 			while(rs.next()) {
		 				int count= rs.getInt("count(zila_panchayat");
		 			}
		 		} catch (SQLException e) {
		 			e.printStackTrace();
		 		}
		 		return user;
		 	}
// get userName and Password 
		 	public Login getUserNameAndPassword(String user_name, String password) {
		 		Login login=null;
		 		try {
		 			String query="select * from  super_admin where user_name = ? and password = ?";
		 			PreparedStatement ps=con.prepareStatement(query);
		 			ps.setString(1, user_name);
		 			ps.setString(2, password);
		 			ResultSet rs=ps.executeQuery();
		 			while(rs.next()) {
		 				 login=new Login();
		 				 login.setSuper_admin_id(rs.getInt("super_admin_id"));
		 				 login.setName(rs.getString("name"));
		 				 login.setAdhar(rs.getLong("adhar"));
		 				 login.setUser_name(rs.getString("user_name"));
		 				 login.setPassword(rs.getString("password"));
		 				 login.setAge(rs.getString("age"));
		 				 login.setProfile(rs.getString("profile"));
		 				 login.setType(rs.getString("type"));
		 				 login.setGender(rs.getString("gender"));
		 				 login.setDate_time(rs.getTimestamp("date_time"));
		 			}
		 		} catch (SQLException e) {
		 			e.printStackTrace();
		 		}
		 		return login;
		 	}
// create new vote value 
		 	public boolean insertNewVoteDetails(GetValue getvalue) {
		 		boolean f=false;
		 		try {
		 			String query="insert into voting_sys(name,adhar,state,dist,city) value(?,?,?,?,?)";
		 			PreparedStatement ps=con.prepareStatement(query);
		 			ps.setString(1, getvalue.getName());
		 			ps.setLong(2, getvalue.getAdhar());
		 			ps.setString(3, getvalue.getState());
		 			ps.setString(4, getvalue.getDist());
		 			ps.setString(5, getvalue.getCity());
		 			ps.executeUpdate();
		 			f=true;
		 		} catch (SQLException e) {
		 			e.printStackTrace();
		 		}
		 		return f;
		 	}
// update vote details 
		 	public boolean updateVoteDetails(int voting_id,String name,Long adhar,String state,String dist,String city) {
		 		boolean f=false;
		 		try {
		 			String query="update voting_sys set name = ?, adhar= ?,state = ?, dist = ?, city = ? where voting_id= ?";
		 			PreparedStatement ps=con.prepareStatement(query);
		 			ps.setString(1, name);
		 			ps.setLong(2, adhar);
		 			ps.setString(3, state);
		 			ps.setString(4, dist);
		 			ps.setString(5, city);
		 			ps.setInt(6, voting_id);
		 			ps.executeUpdate();
		 			f=true;
		 		} catch (SQLException e) {
		 			e.printStackTrace();
		 		}
		 		return f;
		 	}
		 	
// delete vote details 
		 	public boolean deleteVoteDetails(Long adhar) {
		 		boolean f=false;
		 		try {
		 			String query="delete from voting_sys where adhar= ?";
		 			PreparedStatement ps=con.prepareStatement(query);
		 			ps.setLong(1, adhar);
		 			ps.executeUpdate();
		 			f=true;
		 		} catch (SQLException e) {
		 			e.printStackTrace();
		 		}
		 		return f;
		 	}
		 // get All Count Vote 
	 	 	public CountVote getAllCountVote(){
	 	 		CountVote count_vote=null;
	 	 		String query="select count(voting_id) from voting_sys";
	 	 		try {
	 				PreparedStatement ps=con.prepareStatement(query);
	 				ResultSet rs=ps.executeQuery();
	 				while(rs.next()) {
	 					count_vote=new  CountVote();
	 					count_vote.setCount_vote(rs.getInt("count(voting_id)"));
	 				}
	 			} catch (SQLException e) {
	 				e.printStackTrace();
	 			}
	 			return count_vote;
	 	 		
	 	 	}
// get All Count Vote 
	 	 	public StateCountVote getAllStatetVote(String state){
	 	 		StateCountVote state_vote=null;
	 	 		String query="select count(state) from voting_sys where state= ?";
	 	 		try {
	 				PreparedStatement ps=con.prepareStatement(query);
	 				ps.setString(1, state);
	 				ResultSet rs=ps.executeQuery();
	 				while(rs.next()) {
	 					state_vote=new  StateCountVote();
	 					state_vote.setState(rs.getInt("count(state)"));
	 				}
	 			} catch (SQLException e) {
	 				e.printStackTrace();
	 			}
	 			return state_vote;
	 	 		
	 	 	}
// get All Count Admin
	 	 	public AdminCount getAllAdmin(String type){
	 	 		AdminCount adcount=null;
	 	 		String query="select  count(type) from super_admin where type = ?";
	 	 		try {
	 				PreparedStatement ps=con.prepareStatement(query);
	 				ps.setString(1, type);
	 				ResultSet rs=ps.executeQuery();
	 				while(rs.next()) {
	 					adcount=new  AdminCount();
	 					adcount.setAdmincount(rs.getInt("count(type)"));
	 				}
	 			} catch (SQLException e) {
	 				e.printStackTrace();
	 			}
	 			return adcount;
	 	 		
	 	 	}
	 	// insert value from adhar 
		 	public boolean saveAllAdminValue(AdminCount admincount) {
		 		boolean f=false;
		 		try {
		 			String query="insert into super_admin(name,adhar,user_name,password,age,profile,type,gender) values(?,?,?,?,?,?,?,?)";
		 			PreparedStatement ps=con.prepareStatement(query);
		 			ps.setString(1, admincount.getName() );
		 			ps.setLong(2, admincount.getAdhar());
		 			ps.setString(3, admincount.getUser_name());
		 			ps.setString(4, admincount.getPassword());
		 			ps.setString(5, admincount.getAge());
		 			ps.setString(6, admincount.getProfile());
		 			ps.setString(7, admincount.getType());
		 			ps.setString(8, admincount.getGender());
		 			ps.executeUpdate();
		 			 f=true;
		 		} catch (SQLException e) {
		 			e.printStackTrace();
		 		}
				return f;
		 	}
		 	//get all value.....
		 	public Login getAllAdminValue(String user_name) {
		 		Login login=null;
		 		try {
		 			String query="select * from  super_admin where user_name = ?";
		 			PreparedStatement ps=con.prepareStatement(query);
		 			ps.setString(1, user_name);
		 			ResultSet rs=ps.executeQuery();
		 			while(rs.next()) {
		 				 login=new Login();
		 				 login.setSuper_admin_id(rs.getInt("super_admin_id"));
		 				 login.setName(rs.getString("name"));
		 				 login.setAdhar(rs.getLong("adhar"));
		 				 login.setUser_name(rs.getString("user_name"));
		 				 login.setPassword(rs.getString("password"));
		 				 login.setAge(rs.getString("age"));
		 				 login.setProfile(rs.getString("profile"));
		 				 login.setType(rs.getString("type"));
		 				 login.setGender(rs.getString("gender"));
		 				 login.setDate_time(rs.getTimestamp("date_time"));
		 			}
		 		} catch (SQLException e) {
		 			e.printStackTrace();
		 		}
		 		return login;
		 	}
		 // updateAdminDetails  
		 	public boolean updateAdminDetails(int super_admin_id,String name, Long adhar, String user_name,String password,String age, String profile, String type, String gender) {
		 		boolean f=false;
		 		try {
		 			String query="update super_admin set name = ?, adhar= ?,user_name = ?, password = ?, age = ?,profile=?,type=?,gender=? where super_admin_id= ?";
		 			PreparedStatement ps=con.prepareStatement(query);
		 			ps.setString(1, name);
		 			ps.setLong(2, adhar);
		 			ps.setString(3, user_name);
		 			ps.setString(4, password);
		 			ps.setString(5, age);
		 			ps.setString(6, profile);
		 			ps.setString(7, type);
		 			ps.setString(8, gender);
		 			ps.setInt(9, super_admin_id);
		 			ps.executeUpdate();
		 			f=true;
		 		} catch (SQLException e) {
		 			e.printStackTrace();
		 		}
		 		return f;
		 	}
// delete vote details 
		 	public boolean deleteAdminDetails(String user_name) {
		 		boolean f=false;
		 		try {
		 			String query="delete from super_admin where user_name= ?";
		 			PreparedStatement ps=con.prepareStatement(query);
		 			ps.setString(1, user_name);
		 			ps.executeUpdate();
		 			f=true;
		 		} catch (SQLException e) {
		 			e.printStackTrace();
		 		}
		 		return f;
		 	}
// get All CountTotalTurnout are done
	 	 		public CountTotalTurnout getTotalTurnoutVote(){
	 	 			CountTotalTurnout ctt=null;
		 	 		String query="select count(vote_id) from vote_submit";
		 	 		try {
		 				PreparedStatement ps=con.prepareStatement(query);
		 				ResultSet rs=ps.executeQuery();
		 				while(rs.next()) {
		 					ctt=new  CountTotalTurnout();
		 					ctt.setCounttotalturnout(rs.getInt("count(vote_id)"));
		 				}
		 			} catch (SQLException e) {
		 				e.printStackTrace();
		 			}
		 			return ctt;
		 	 		
		 	 	}
	 	 	// get All Type 
		 	 	public ArrayList<Type> getAllType(){
		 	 		ArrayList<Type> type=new ArrayList<Type>();
		 	 		String query="select * from type";
		 	 		try {
		 				PreparedStatement ps=con.prepareStatement(query);
		 				ResultSet rs=ps.executeQuery();
		 				while(rs.next()) {
		 					String  type_value=rs.getString("type_value");
		 					Type t=new Type(type_value);
		 					type.add(t);
		 				}
		 			} catch (SQLException e) {
		 				e.printStackTrace();
		 			}
		 			return type;
		 	 		
		 	 	}
		 	// get All State 
		 	 	public ArrayList<State> getAllState(){
		 	 		ArrayList<State> state=new ArrayList<State>();
		 	 		String query="select * from state";
		 	 		try {
		 				PreparedStatement ps=con.prepareStatement(query);
		 				ResultSet rs=ps.executeQuery();
		 				while(rs.next()) {
		 					String  state_s=rs.getString("state_s");
		 					State state1=new State(state_s);
		 					state.add(state1);
		 				}
		 			} catch (SQLException e) {
		 				e.printStackTrace();
		 			}
		 			return state;
		 	 		
		 	 	}

		 	// get All Zila Vote Counting
		 	 	public ZilaPanchayatCount getAllZilaPanchayatVoteCounting(String zila_panchayat){
		 	 		ZilaPanchayatCount zpcount=null;
		 	 		String query="select count(zila_panchayat) from vote_submit where zila_panchayat = ?";
		 	 		try {
		 				PreparedStatement ps=con.prepareStatement(query);
		 				ps.setString(1, zila_panchayat);
		 				ResultSet rs=ps.executeQuery();
		 				while(rs.next()) {
		 					zpcount=new  ZilaPanchayatCount();
		 					zpcount.setCount(rs.getInt("count(zila_panchayat)"));
		 				}
		 			} catch (SQLException e) {
		 				e.printStackTrace();
		 			}
		 			return zpcount;
		 	 		
		 	 	}
		 	// get All block Vote Counting
		 	 	public BlockPanchayatVoteCounting getAllBlockPanchayatVoteCounting(String block_panchayat){
		 	 		BlockPanchayatVoteCounting bpvc=null;
		 	 		String query="select count(block_panchayat) from vote_submit where block_panchayat = ?";
		 	 		try {
		 				PreparedStatement ps=con.prepareStatement(query);
		 				ps.setString(1, block_panchayat);
		 				ResultSet rs=ps.executeQuery();
		 				while(rs.next()) {
		 					bpvc=new  BlockPanchayatVoteCounting();
		 					bpvc.setCount(rs.getInt("count(block_panchayat)"));
		 				}
		 			} catch (SQLException e) {
		 				e.printStackTrace();
		 			}
		 			return bpvc;
		 	 		
		 	 	}
		 	// get All Zila Vote Counting
		 	 	public GramPanchayatVoteCounting getAllGramPanchayatVoteCounting(String block_panchayat){
		 	 		GramPanchayatVoteCounting gpvc=null;
		 	 		String query="select count(gram_panchayat) from vote_submit where gram_panchayat = ?";
		 	 		try {
		 				PreparedStatement ps=con.prepareStatement(query);
		 				ps.setString(1, block_panchayat);
		 				ResultSet rs=ps.executeQuery();
		 				while(rs.next()) {
		 					gpvc=new  GramPanchayatVoteCounting();
		 					gpvc.setCount(rs.getInt("count(gram_panchayat)"));
		 				}
		 			} catch (SQLException e) {
		 				e.printStackTrace();
		 			}
		 			return gpvc;
		 	 		
		 	 	}
		 	 	//get all Admin value 
		 	 	public ArrayList<Login> getAllAdmin(){
		 	 		ArrayList<Login> login=new ArrayList<Login>();
		 	 		String query="select * from super_admin";
		 	 		try {
		 				PreparedStatement ps=con.prepareStatement(query);
		 				ResultSet rs=ps.executeQuery();
		 				while(rs.next()) {
		 					int super_admin_id=rs.getInt("super_admin_id");
		 					String  name=rs.getString("name");
		 					Long  adhar=rs.getLong("adhar");
		 					String  user_name=rs.getString("user_name");
		 					String  password=rs.getString("password");
		 					String  age=rs.getString("age");
		 					String  profile=rs.getString("profile");
		 					String  type=rs.getString("type");
		 					String  gender=rs.getString("gender");
		 					Timestamp  date_time=rs.getTimestamp("date_time");
		 					Login login1=new Login(super_admin_id,name,adhar,user_name,password,age,profile,type,gender,date_time);
		 					login.add(login1);
		 				}
		 			} catch (SQLException e) {
		 				e.printStackTrace();
		 			}
		 			return login;
		 	 		
		 	 	}
		//send notification
		 	 	public boolean insertNotification(Notification nf) {
		 	 		boolean f=false;
		 	 		String query="insert into notification_send(notification) value(?)";
		 	 		try {
						PreparedStatement ps=con.prepareStatement(query);
						ps.setString(1, nf.getNotification());
						ps.executeUpdate();
						f=true;
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return f;
		 	 		
		 	 	}
		 	 	
		 	 //get all Message Super Admin value 
		 	 	public ArrayList<Notification> getAllNotification(){
		 	 		ArrayList<Notification> notification2=new ArrayList<Notification>();
		 	 		String query="select * from notification_send";
		 	 		try {
		 				PreparedStatement ps=con.prepareStatement(query);
		 				ResultSet rs=ps.executeQuery();
		 				while(rs.next()) {
		 					int notfication_id=rs.getInt("notfication_id");
		 					String  notification=rs.getString("notification");
		 					Timestamp  date_time=rs.getTimestamp("date_time");
		 					Notification notification1=new Notification(notfication_id,notification,date_time);
		 					notification2.add(notification1);
		 				}
		 			} catch (SQLException e) {
		 				e.printStackTrace();
		 			}
		 			return notification2;
		 	 		
		 	 	}
		 	 //send Reply message
		 	 	public boolean insertReplyMessage(AdminReplyMessage arm) {
		 	 		boolean f=false;
		 	 		String query="insert into reply_noti(reply_message,user_name,name) value(?,?,?)";
		 	 		try {
						PreparedStatement ps=con.prepareStatement(query);
						ps.setString(1, arm.getReply_message());
						ps.setString(2, arm.getUser_name());
						ps.setString(3, arm.getName());
						ps.executeUpdate();
						f=true;
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return f;
		 	 		
		 	 	}
		 	 //get all Message  Admin value 
		 	 	public ArrayList<AdminReplyMessage> getAllAdminMessage(){
		 	 		ArrayList<AdminReplyMessage> arm=new ArrayList<AdminReplyMessage>();
		 	 		String query="select * from reply_noti";
		 	 		try {
		 				PreparedStatement ps=con.prepareStatement(query);
		 				ResultSet rs=ps.executeQuery();
		 				while(rs.next()) {
		 					int reply_id=rs.getInt("reply_id");
		 					String  reply_message=rs.getString("reply_message");
		 					String  user_name=rs.getString("user_name");
		 					String  name=rs.getString("name");
		 					Timestamp  date_time=rs.getTimestamp("date_time");
		 					AdminReplyMessage arm1=new AdminReplyMessage(reply_id,reply_message,user_name,name,date_time);
		 					arm.add(arm1);
		 				}
		 			} catch (SQLException e) {
		 				e.printStackTrace();
		 			}
		 			return arm;
		 	 		
		 	 	}
		 	 	
		 	
}
