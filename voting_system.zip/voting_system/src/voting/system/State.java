package voting.system;

public class State {
	private String state_s;

	public State(String state_s) {
		super();
		this.state_s = state_s;
	}

	public State() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getState_s() {
		return state_s;
	}

	public void setState_s(String state_s) {
		this.state_s = state_s;
	}
	
}
