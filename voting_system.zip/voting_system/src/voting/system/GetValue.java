package voting.system;

import java.sql.Timestamp;

public class GetValue {
	private int voting_id;
	private String name;
	private Long adhar;
	private String state;
	private String dist;
	private String city;
	private Timestamp date_time;
	public GetValue(int voting_id, String name, Long adhar, String state, String dist, String city,
			Timestamp date_time) {
		super();
		this.voting_id = voting_id;
		this.name = name;
		this.adhar = adhar;
		this.state = state;
		this.dist = dist;
		this.city = city;
		this.date_time = date_time;
	}
	public GetValue() {
		super();
	}
	
	public GetValue(String name, Long adhar, String state, String dist, String city) {
		super();
		this.name = name;
		this.adhar = adhar;
		this.state = state;
		this.dist = dist;
		this.city = city;
	}
	public int getVoting_id() {
		return voting_id;
	}
	public void setVoting_id(int voting_id) {
		this.voting_id = voting_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getAdhar() {
		return adhar;
	}
	public void setAdhar(Long adhar) {
		this.adhar = adhar;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDist() {
		return dist;
	}
	public void setDist(String dist) {
		this.dist = dist;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Timestamp getDate_time() {
		return date_time;
	}
	public void setDate_time(Timestamp date_time) {
		this.date_time = date_time;
	}
	 
}
