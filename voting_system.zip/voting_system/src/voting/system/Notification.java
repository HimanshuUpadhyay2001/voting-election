package voting.system;

import java.sql.Timestamp;

public class Notification {
	private int notfication_id;
	private String notification;
	private Timestamp date_time;
	public Notification(int notfication_id, String notification, Timestamp date_time) {
		super();
		this.notfication_id = notfication_id;
		this.notification = notification;
		this.date_time = date_time;
	}
	public Notification(String notification) {
		super();
		this.notification = notification;
	}
	public Notification() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getNotfication_id() {
		return notfication_id;
	}
	public void setNotfication_id(int notfication_id) {
		this.notfication_id = notfication_id;
	}
	public String getNotification() {
		return notification;
	}
	public void setNotification(String notification) {
		this.notification = notification;
	}
	public Timestamp getDate_time() {
		return date_time;
	}
	public void setDate_time(Timestamp date_time) {
		this.date_time = date_time;
	}
	
	
}
