package voting.system;

public class GramPanchayatVoteCounting {
	private int count;

	public GramPanchayatVoteCounting(int count) {
		super();
		this.count = count;
	}

	public GramPanchayatVoteCounting() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
}
