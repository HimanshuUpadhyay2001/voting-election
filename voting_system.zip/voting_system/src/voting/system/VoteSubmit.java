package voting.system;

import java.sql.Timestamp;

public class VoteSubmit {
	private int vote_id;
	private String name;
	private Long adhar;
	private String state;
	private String dist;
	private String city;
	private String zila_panchayat;
	private String block_panchayat;
	private String gram_panchayat;
	private Timestamp date_time;
	public VoteSubmit(int vote_id, String name, Long adhar, String state, String dist, String city,
			String zila_panchayat, String block_panchayat, String gram_panchayat, Timestamp date_time) {
		super();
		this.vote_id = vote_id;
		this.name = name;
		this.adhar = adhar;
		this.state = state;
		this.dist = dist;
		this.city = city;
		this.zila_panchayat = zila_panchayat;
		this.block_panchayat = block_panchayat;
		this.gram_panchayat = gram_panchayat;
		this.date_time = date_time;
	}
	public VoteSubmit(String name, Long adhar, String state, String dist, String city, String zila_panchayat,
			String block_panchayat, String gram_panchayat) {
		super();
		this.name = name;
		this.adhar = adhar;
		this.state = state;
		this.dist = dist;
		this.city = city;
		this.zila_panchayat = zila_panchayat;
		this.block_panchayat = block_panchayat;
		this.gram_panchayat = gram_panchayat;
	}
	public VoteSubmit() {
		super();
	}
	public int getVote_id() {
		return vote_id;
	}
	public void setVote_id(int vote_id) {
		this.vote_id = vote_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getAdhar() {
		return adhar;
	}
	public void setAdhar(Long adhar) {
		this.adhar = adhar;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDist() {
		return dist;
	}
	public void setDist(String dist) {
		this.dist = dist;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZila_panchayat() {
		return zila_panchayat;
	}
	public void setZila_panchayat(String zila_panchayat) {
		this.zila_panchayat = zila_panchayat;
	}
	public String getBlock_panchayat() {
		return block_panchayat;
	}
	public void setBlock_panchayat(String block_panchayat) {
		this.block_panchayat = block_panchayat;
	}
	public String getGram_panchayat() {
		return gram_panchayat;
	}
	public void setGram_panchayat(String gram_panchayat) {
		this.gram_panchayat = gram_panchayat;
	}
	public Timestamp getDate_time() {
		return date_time;
	}
	public void setDate_time(Timestamp date_time) {
		this.date_time = date_time;
	}
	
}
