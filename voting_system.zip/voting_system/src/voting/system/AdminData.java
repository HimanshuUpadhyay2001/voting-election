package voting.system;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

/**
 * Servlet implementation class AdminData
 */
@WebServlet("/AdminData")
@MultipartConfig
public class AdminData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminData() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		String name=request.getParameter("name");
		String Adhar=request.getParameter("adhar");
		Long adhar=Long.parseLong(Adhar);
		String user_name=request.getParameter("user_name");
		String password=request.getParameter("password");
		String age=request.getParameter("age");
		Part part=request.getPart("profile");
		String profile=part.getSubmittedFileName();
		String type=request.getParameter("type");
		String gender=request.getParameter("gender");
		try {
			AdminCount admincount=new AdminCount(name,adhar,user_name,password,age,profile,type,gender);
			DBAccess dbl = new DBAccess(DBConnection.getConnection());
			if(dbl.saveAllAdminValue(admincount)) {
				HttpSession s=request.getSession();
	    		Message m=new Message("Admin Successfully Register","error","alert-success");
	    		s.setAttribute("msg",m);
				response.sendRedirect("super-admin.jsp");
			}else {
				HttpSession s=request.getSession();
				Message m=new Message("Admin Not Register","error","alert-danger");
				s.setAttribute("msg",m);
				response.sendRedirect("super-admin.jsp");
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
