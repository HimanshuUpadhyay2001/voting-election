package voting.system;

public class CountTotalTurnout {
	private int counttotalturnout;

	public CountTotalTurnout(int counttotalturnout) {
		super();
		this.counttotalturnout = counttotalturnout;
	}

	public CountTotalTurnout() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCounttotalturnout() {
		return counttotalturnout;
	}

	public void setCounttotalturnout(int counttotalturnout) {
		this.counttotalturnout = counttotalturnout;
	}
	
}
