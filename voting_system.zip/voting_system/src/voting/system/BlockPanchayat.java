package voting.system;

import java.sql.Timestamp;

public class BlockPanchayat {
	private int block_id;
	private String symbol_name;
	private String symbol_pick;
	private String name;
	private Timestamp date_time;
	public BlockPanchayat(int block_id, String symbol_name, String symbol_pick, String name, Timestamp date_time) {
		super();
		this.block_id = block_id;
		this.symbol_name = symbol_name;
		this.symbol_pick = symbol_pick;
		this.name = name;
		this.date_time = date_time;
	}
	public BlockPanchayat(String symbol_name, String symbol_pick, String name) {
		super();
		this.symbol_name = symbol_name;
		this.symbol_pick = symbol_pick;
		this.name = name;
	}
	public BlockPanchayat() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getBlock_id() {
		return block_id;
	}
	public void setBlock_id(int block_id) {
		this.block_id = block_id;
	}
	public String getSymbol_name() {
		return symbol_name;
	}
	public void setSymbol_name(String symbol_name) {
		this.symbol_name = symbol_name;
	}
	public String getSymbol_pick() {
		return symbol_pick;
	}
	public void setSymbol_pick(String symbol_pick) {
		this.symbol_pick = symbol_pick;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Timestamp getDate_time() {
		return date_time;
	}
	public void setDate_time(Timestamp date_time) {
		this.date_time = date_time;
	}
	
}
